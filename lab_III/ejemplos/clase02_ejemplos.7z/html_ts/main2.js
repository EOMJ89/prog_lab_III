"use strict";
function Saludar() {
    var nombre = document.getElementById("txtNombre").value;
    alert("Hola " + nombre);
}
//# sourceMappingURL=main2.js.map