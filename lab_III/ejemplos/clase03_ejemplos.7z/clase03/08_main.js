"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var _04_claseAbstracta_1 = require("./04_claseAbstracta"); //IMPORTO AUTO
var miAuto = new _04_claseAbstracta_1.Auto("NARANJA", 150, "FIAT");
console.log(miAuto.Mostrar());
miAuto.Acelerar();
miAuto.Marca = "RENAULT";
console.log(miAuto.Marca);
//# sourceMappingURL=08_main.js.map