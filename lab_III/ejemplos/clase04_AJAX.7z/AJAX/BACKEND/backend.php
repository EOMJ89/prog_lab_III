<?php

var_dump($_GET);

var_dump($_POST);